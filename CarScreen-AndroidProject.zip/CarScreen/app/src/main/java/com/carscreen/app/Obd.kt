package com.carscreen.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

/** اتصال مع قطعة ELM327 WiFi (عادة 192.168.0.10:35000) */
class Obd(
    private val ctx: Context,
    private val onData: (String) -> Unit,
    private val onStatus: (String) -> Unit
) {
    @Volatile private var running = false
    private var thread: Thread? = null
    private var sock: Socket? = null

    fun start(host: String, port: Int) {
        stop()
        running = true
        thread = Thread { run(host, port) }.also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
        try { sock?.close() } catch (_: Exception) {}
        thread?.interrupt()
        thread = null
    }

    private fun wifi(): Network? {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.allNetworks.firstOrNull {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }
    }

    private fun run(host: String, port: Int) {
        try {
            onStatus("connecting")
            val s = wifi()?.socketFactory?.createSocket() ?: Socket()
            sock = s
            s.connect(InetSocketAddress(host, port), 6000)
            s.soTimeout = 2500
            val out = s.getOutputStream()
            val inp = s.getInputStream()

            fun cmd(c: String): String {
                out.write((c + "\r").toByteArray()); out.flush()
                val sb = StringBuilder(); val buf = ByteArray(256)
                val end = System.currentTimeMillis() + 3000
                while (System.currentTimeMillis() < end) {
                    val n = try { inp.read(buf) } catch (e: SocketTimeoutException) { -1 }
                    if (n < 0) break
                    sb.append(String(buf, 0, n))
                    if (sb.contains('>')) break
                }
                return sb.toString().replace(">", "").trim()
            }

            // يرجع بايتات الرد بعد الترويسة مثل 410C
            fun bytes(resp: String, header: String): List<Int>? {
                val clean = resp.replace(Regex("\\s"), "").uppercase()
                val i = clean.indexOf(header)
                if (i < 0) return null
                val hex = clean.substring(i + header.length)
                val list = ArrayList<Int>()
                var k = 0
                while (k + 2 <= hex.length) {
                    val v = hex.substring(k, k + 2).toIntOrNull(16) ?: break
                    list.add(v); k += 2
                }
                return if (list.isEmpty()) null else list
            }

            cmd("ATZ"); cmd("ATE0"); cmd("ATL0"); cmd("ATS0"); cmd("ATSP0")
            cmd("0100")
            onStatus("connected")

            var n = 0
            while (running) {
                val j = JSONObject()
                bytes(cmd("010C"), "410C")?.let { if (it.size >= 2) j.put("rpm", (it[0] * 256 + it[1]) / 4.0) }
                bytes(cmd("010D"), "410D")?.let { j.put("speed", it[0]) }
                bytes(cmd("0105"), "4105")?.let { j.put("coolant", it[0] - 40) }
                bytes(cmd("0104"), "4104")?.let { j.put("load", it[0] * 100.0 / 255) }
                if (n % 4 == 0) {
                    bytes(cmd("012F"), "412F")?.let { j.put("fuel", it[0] * 100.0 / 255) }
                    bytes(cmd("015C"), "415C")?.let { j.put("oil", it[0] - 40) }
                    bytes(cmd("0142"), "4142")?.let { if (it.size >= 2) j.put("volt", (it[0] * 256 + it[1]) / 1000.0) }
                }
                n++
                onData(j.toString())
                Thread.sleep(250)
            }
        } catch (e: InterruptedException) {
        } catch (e: Exception) {
            if (running) onStatus("error:" + (e.message ?: e.javaClass.simpleName))
        } finally {
            try { sock?.close() } catch (_: Exception) {}
            if (running) { running = false }
        }
    }
}
